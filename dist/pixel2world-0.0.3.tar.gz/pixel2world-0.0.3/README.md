# pixel2world_base
 Convert image coordinates to global coordinates
